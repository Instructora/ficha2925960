import pytest
from app import create_app
from app.extensions import db
from app.config import TestingConfig
from app.models.user import User
from flask_jwt_extended import create_access_token


@pytest.fixture
def app():
    app = create_app(TestingConfig)

    with app.app_context():
        db.drop_all()
        db.create_all() # limpiar tablas si existen
        yield app
        db.session.remove()
        db.drop_all()  # limpiar al finalizar


@pytest.fixture
def client(app):
    return app.test_client()

@pytest.fixture
def user_token(app):
    with app.app_context():
        user = User(username="testuser")
        user.set_password("123")  # Usa tu método seguro de set_password
        db.session.add(user)
        db.session.commit()
        token = create_access_token(identity=str(user.id))# ¡Forzar string!
        return token
