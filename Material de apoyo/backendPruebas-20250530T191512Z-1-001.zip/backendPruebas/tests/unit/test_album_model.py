from app.models.album import Album

def test_album_creation():
    album = Album(title='Test Album', year=2024, description='Descripción de prueba', medium='CD', user_id=1)
    assert album.title == 'Test Album'
    assert album.year == 2024
    assert album.medium == 'CD'
    assert album.user_id == 1
