from app.models.user import User
from app.models.album import Album  # 👈 necesario para evitar error

def test_user_creation():
    user = User(username='testuser')
    user.set_password('1234')

    assert user.username == 'testuser'
    assert user.check_password('1234') is True
    assert user.check_password('wrongpassword') is False

