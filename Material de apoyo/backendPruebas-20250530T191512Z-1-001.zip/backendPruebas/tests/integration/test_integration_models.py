# se utiliza la librería faker 
import pytest
from faker import Faker
from app import create_app
from app.extensions import db
from app.models.user import User
from app.models.album import Album
from app.models.song import Song
from app.config import TestingConfig  # Importa la configuración de test

faker = Faker()

@pytest.fixture
def app():
    app = create_app(TestingConfig)  # Usa la configuración de test que tiene MySQL para pruebas

    with app.app_context():
        db.drop_all()     # limpia todo antes de empezar
        db.create_all()   # crea las tablas
        yield app
        db.session.remove()
        # db.drop_all()   # opcional: limpia al final

@pytest.fixture
def client(app):
    return app.test_client()

def test_create_user_album_song_with_faker(app):
    with app.app_context():
        username = faker.user_name()
        password = faker.password()

        user = User(username=username)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        album = Album(
            title=faker.catch_phrase(),
            year=faker.random_int(min=1970, max=2025),
            description=faker.text(),
            medium=faker.random_element(elements=("CD", "vinilo", "casete")),
            user_id=user.id
        )
        db.session.add(album)
        db.session.commit()

        song = Song(
            title=faker.sentence(nb_words=2),
            duration_minutes=faker.random_int(min=1, max=5),
            duration_seconds=faker.random_int(min=0, max=59),
            artist=faker.name()
        )
        db.session.add(song)
        db.session.commit()

        album.songs.append(song)
        db.session.commit()

        assert user.id is not None
        assert album in user.albums
        assert song in album.songs
