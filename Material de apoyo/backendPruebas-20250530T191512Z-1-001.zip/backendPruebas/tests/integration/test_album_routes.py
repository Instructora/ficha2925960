import pytest
from faker import Faker
from app.models.album import Album
from app.models.user import User
from app.extensions import db
from flask_jwt_extended import create_access_token
import json

faker = Faker()

def auth_headers(token):
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

def test_create_album(client, user_token):
    data = {
        "title": faker.catch_phrase(),
        "year": faker.random_int(min=1970, max=2025),
        "description": faker.text(),
        "medium": faker.random_element(elements=("CD", "vinilo", "casete"))
    }
    response = client.post('/api/albums/', headers=auth_headers(user_token), json=data)
    assert response.status_code == 201
    resp_json = response.get_json()
    assert resp_json["title"] == data["title"]
    assert resp_json["medium"] == data["medium"]

def test_list_albums(client, user_token, app):
    with app.app_context():
        from flask_jwt_extended import decode_token
        decoded = decode_token(user_token)
        user_id = decoded['sub']

        album = Album(
            title=faker.catch_phrase(),
            year=faker.random_int(min=1970, max=2025),
            description=faker.text(),
            medium=faker.random_element(elements=("CD", "vinilo", "casete")),
            user_id=user_id
        )
        db.session.add(album)
        db.session.commit()

        # ✅ Guarda el id ANTES de salir del contexto
        album_id = album.id

    response = client.get('/api/albums/', headers=auth_headers(user_token))
    assert response.status_code == 200
    albums = response.get_json()

    # ✅ Compara contra album_id en lugar de album.id
    assert any(a["id"] == album_id for a in albums)


def test_update_album(client, user_token, app):
    with app.app_context():
        from flask_jwt_extended import decode_token
        user_id = decode_token(user_token)['sub']

        album = Album(
            title="Original Title",
            year=2000,
            description="Original description",
            medium="CD",
            user_id=user_id
        )
        db.session.add(album)
        db.session.commit()

        album_id = album.id

    update_data = {
        "title": "Updated Title",
        "year": 2021,
        "description": "Updated description",
        "medium": "vinilo"
    }
    response = client.put(f'/api/albums/{album_id}', headers=auth_headers(user_token), json=update_data)
    assert response.status_code == 200
    resp_json = response.get_json()
    assert resp_json["title"] == update_data["title"]
    assert resp_json["medium"] == update_data["medium"]

def test_delete_album(client, user_token, app):
    with app.app_context():
        from flask_jwt_extended import decode_token
        user_id = decode_token(user_token)['sub']

        album = Album(
            title="To be deleted",
            year=1999,
            description="Delete me",
            medium="casete",
            user_id=user_id
        )
        db.session.add(album)
        db.session.commit()

        album_id = album.id

    response = client.delete(f'/api/albums/{album_id}', headers=auth_headers(user_token))
    assert response.status_code == 200
    resp_json = response.get_json()
    assert resp_json["message"] == "Álbum eliminado"


