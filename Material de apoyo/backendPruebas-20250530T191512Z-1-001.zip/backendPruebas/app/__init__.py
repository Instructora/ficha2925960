from flask import Flask
from .config import Config
from .extensions import db, migrate, jwt

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Inicializar extensiones
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)

    # Registrar Blueprints
    from .routes.auth import auth_bp
    from .routes.albums import albums_bp
    from .routes.songs import songs_bp

    app.register_blueprint(auth_bp, url_prefix="/api/auth")
    app.register_blueprint(albums_bp, url_prefix="/api/albums")
    app.register_blueprint(songs_bp, url_prefix="/api/songs")

    # Importar modelos para migraciones
    from .models import user, album, song

    return app
