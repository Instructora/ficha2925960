# app/utils/auth.py

from flask_jwt_extended import get_jwt_identity
from app.models.user import User
from app.extensions import db

def get_current_user():
    """
    Devuelve el usuario actualmente autenticado según el JWT.
    """
    user_id = get_jwt_identity()
    if user_id is None:
        return None

    return db.session.get(User, user_id)
