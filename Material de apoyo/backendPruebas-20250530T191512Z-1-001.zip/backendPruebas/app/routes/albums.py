# app/routes/albums.py
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.models.album import Album
from app.models.user import User
from app.extensions import db

albums_bp = Blueprint('albums', __name__)

@albums_bp.route('/', methods=['POST'])
@jwt_required()
def create_album():
    data = request.get_json()
    title = data.get('title')
    year = data.get('year')
    description = data.get('description')
    medium = data.get('medium')

    if not title or not year or not medium:
        return jsonify({"error": "Faltan campos obligatorios"}), 400

    user_id = get_jwt_identity()

    new_album = Album(
        title=title,
        year=year,
        description=description,
        medium=medium,
        user_id=user_id
    )
    db.session.add(new_album)
    db.session.commit()

    return jsonify(new_album.to_dict()), 201

@albums_bp.route('/', methods=['GET'])
@jwt_required()
def list_albums():
    user_id = get_jwt_identity()
    albums = Album.query.filter_by(user_id=user_id).all()
    return jsonify([album.to_dict() for album in albums]), 200

@albums_bp.route('/<int:album_id>', methods=['PUT'])
@jwt_required()
def update_album(album_id):
    user_id = get_jwt_identity()
    album = Album.query.filter_by(id=album_id, user_id=user_id).first()
    if not album:
        return jsonify({"error": "Álbum no encontrado"}), 404

    data = request.get_json()
    album.title = data.get('title', album.title)
    album.year = data.get('year', album.year)
    album.description = data.get('description', album.description)
    album.medium = data.get('medium', album.medium)

    db.session.commit()
    return jsonify(album.to_dict()), 200

@albums_bp.route('/<int:album_id>', methods=['DELETE'])
@jwt_required()
def delete_album(album_id):
    user_id = get_jwt_identity()
    album = Album.query.filter_by(id=album_id, user_id=user_id).first()
    if not album:
        return jsonify({"error": "Álbum no encontrado"}), 404

    db.session.delete(album)
    db.session.commit()
    return jsonify({"message": "Álbum eliminado"}), 200


@albums_bp.route('/<int:album_id>', methods=['GET'])
@jwt_required()
def get_album(album_id):
    user_id = get_jwt_identity()
    album = Album.query.filter_by(id=album_id, user_id=user_id).first()
    if not album:
        return jsonify({"error": "Álbum no encontrado"}), 404

    return jsonify(album.to_dict(include_songs=True)), 200

