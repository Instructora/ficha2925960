# app/routes/songs.py

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.models.song import Song
from app.models.album import Album
from app.extensions import db

songs_bp = Blueprint('songs', __name__)

@songs_bp.route('/', methods=['POST'])
@jwt_required()
def create_song():
    data = request.get_json()
    title = data.get('title')
    duration_minutes = data.get('duration_minutes')
    duration_seconds = data.get('duration_seconds')
    artist = data.get('artist')
    album_id = data.get('album_id')

    if not title or duration_minutes is None or duration_seconds is None or not artist:
        return jsonify({"error": "Faltan campos obligatorios"}), 400

    song = Song(
        title=title,
        duration_minutes=duration_minutes,
        duration_seconds=duration_seconds,
        artist=artist
    )
    db.session.add(song)
    db.session.commit()

    if album_id:
        album = Album.query.filter_by(id=album_id, user_id=get_jwt_identity()).first()
        if album:
            album.songs.append(song)
            db.session.commit()

    return jsonify(song.to_dict()), 201

@songs_bp.route('/', methods=['GET'])
@jwt_required()
def list_songs():
    songs = Song.query.all()
    return jsonify([song.to_dict() for song in songs]), 200

@songs_bp.route('/<int:song_id>', methods=['PUT'])
@jwt_required()
def update_song(song_id):
    song = Song.query.get(song_id)
    if not song:
        return jsonify({"error": "Canción no encontrada"}), 404

    data = request.get_json()
    song.title = data.get('title', song.title)
    song.duration_minutes = data.get('duration_minutes', song.duration_minutes)
    song.duration_seconds = data.get('duration_seconds', song.duration_seconds)
    song.artist = data.get('artist', song.artist)
    db.session.commit()

    return jsonify(song.to_dict()), 200

@songs_bp.route('/<int:song_id>', methods=['DELETE'])
@jwt_required()
def delete_song(song_id):
    song = Song.query.get(song_id)
    if not song:
        return jsonify({"error": "Canción no encontrada"}), 404

    db.session.delete(song)
    db.session.commit()
    return jsonify({"message": "Canción eliminada"}), 200
