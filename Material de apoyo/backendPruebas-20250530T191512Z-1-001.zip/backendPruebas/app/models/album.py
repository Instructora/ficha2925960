from app.extensions import db

album_song = db.Table(
    'album_song',
    db.Column('album_id', db.Integer, db.ForeignKey('album.id'), primary_key=True),
    db.Column('song_id', db.Integer, db.ForeignKey('song.id'), primary_key=True)
)

class Album(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    year = db.Column(db.Integer)
    description = db.Column(db.Text)
    medium = db.Column(db.String(50))  # CD, vinilo, casete, etc.
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

    songs = db.relationship('Song', secondary=album_song, back_populates='albums')
    user = db.relationship('User', back_populates='albums') #nueva linea agregada

    def __repr__(self):
        return f'<Album {self.title}>'
    
    def to_dict(self, include_songs=False):
        data = {
            "id": self.id,
            "title": self.title,
            "year": self.year,
            "description": self.description,
            "medium": self.medium,
            "user_id": self.user_id,
        }
        if include_songs:
            data["songs"] = [song.to_dict() for song in self.songs]
        return data


