from app.extensions import db
from app.models.album import album_song  # importar la tabla intermedia

class Song(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    duration_minutes = db.Column(db.Integer, nullable=False)
    duration_seconds = db.Column(db.Integer, nullable=False)
    artist = db.Column(db.String(100), nullable=False)

    albums = db.relationship('Album', secondary=album_song, back_populates='songs')

    def __repr__(self):
        return f'<Song {self.title} - {self.artist}>'
    
    def to_dict(self):
        return {
                "id": self.id,
        "title": self.title
        }




